Python Version checked: 3.9+

Grading: run
>>>./grade.sh

Collecting results (generate report.csv), run:
>>>python3 report.py
